<?php
ini_set("session.save_path", "C:/xampp/sessionData");  //adapt this to your //own folder structure for xampp if using xampp
//ini_set("session.save_path", "0;644;/var/www/html/sessionData"); 
session_start(); 

if (!isset($_SESSION['logged-in']) || $_SESSION['logged-in'] !== true) {
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
     <meta charset="utf-8" />
     <title>Excursion Selection Confirmed</title>
  </head>
 <body>
<?php

// Get the excursionID from the form
$excursionID = array_key_exists('excursionID', $_REQUEST) ? $_REQUEST['excursionID'] : null;

$excursionID = trim($excursionID);

$errors = false;

  // Validate required field
if (empty($excursionID)) {
    echo "<p>You have not selected an excursion</p>\n";
    $errors = true;
}

if ($errors) {
    echo "<p>Please try <h2><a href='excursionForm.php'>again</a></h2></p>\n";
}
else {
   // Database connection
    require_once 'functions.php';
    $conn = getConnection();
    
 // Retrieve the full excursion details from the database using the excursionID

 $selectSQL = "SELECT excursion_name, description, price_per_person, location 
                  FROM excursions 
                  WHERE excursionID = ?";
    //  prepared statement against SQL injection
    if ($stmt = mysqli_prepare($conn, $selectSQL)) {
        // Bind the excursionID parameter
        mysqli_stmt_bind_param($stmt, "i", $excursionID);
        mysqli_stmt_execute($stmt);
        
        // Bind result variables
        mysqli_stmt_bind_result($stmt, $excursion_name, $description,          $price_per_person, $location);
        
        // Fetch the result
        if (mysqli_stmt_fetch($stmt)) {
            // Display the selected excursion details 
      
            // Show success message with output
            echo "<div>";
            echo "<h1>Submitted Excursion Form Received! ✓</h1>";
            echo "<p><strong>Your Excursion Option has been successfully                        recorded as!.</strong></p>";
            echo "</div>"; 
             
            // Sanitize the displaying Dynamic data retrieved from DB with                      htmlspecialchars() on the web
            echo "<h2>Your Excursion Selection:</h2>";
            echo "<h3><strong>Excursion Name ::-</strong> " . htmlspecialchars($excursion_name, ENT_QUOTES, 'UTF-8') . "</h3>";
            echo "<h3><strong>Description ::-</strong> " . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . "</h3>";
            echo "<h3><strong>Price_Per_Person ::-</strong> " . htmlspecialchars($price_per_person, ENT_QUOTES, 'UTF-8') . "</h3>";
            echo "<h3><strong>Location ::-</strong> " . htmlspecialchars($location, ENT_QUOTES, 'UTF-8') . "</h3>";

        } else {
            echo "<p>Error: Excursion not found in database.</p>\n";
        }
        
        mysqli_stmt_close($stmt);
    }
    else {
        echo "<p>Could not prepare statement</p>";
    }
    
    mysqli_close($conn);
}

     // Navigation links
       echo "<hr>";
      echo "<h2>Navigation:</h2>";
      echo "<h2><a href='excursionForm.php'>Select Another Excursion</a></h2>\n";
      echo "<h2><a href='excursionDetailsPage.php'>Excursion Details</a></h2>\n";
      echo "<h2><a href='bookingForm.php'>Make a Booking</a></h2>\n"; 
      echo "<h2><a href='logout.php'>Logout</a></h2>\n"; 
            
?>
</body>
</html>