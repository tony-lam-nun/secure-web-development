<?php
ini_set("session.save_path", "C:/xampp/sessionData");  //adapt this to your //own folder structure for xampp if using xampp
//ini_set("session.save_path", "0;644;/var/www/html/sessionData"); 
session_start(); 

if (!isset($_SESSION['logged-in']) || $_SESSION['logged-in'] !== true) {
    header("Location: login.php");
    exit();
}
?>




<!DOCTYPE html>
<html lang="en">
 <head>
       <meta charset="utf-8">
       <title>Excursion DayTrip In Turkey</title>
       <link href="../assets/stylesheets/excursionDetailsPage.css"          rel="stylesheet" type="text/css">
 </head>
 <body>
   <div class="gridContainer">
    <header class="header">
      <img src="../assets/images/incoastlineIstanbul.jpg" alt="coastlineIstanbul">
       <h1>Excursion Details Page</h1>
       <p>Find here details of the available day trip excursions</p>
   </header>
   <!--Start of nav section-->
   <nav class="nav">
     <ul>
         <li><a href='index.html'>Home</a></li>
         <li><a href='bookingForm.php'>Booking</a></li>
         <li><a href='excursionForm.php'>Excursion</a></li>
         <li><a href='logout.php'>Logout</a></li>
     </ul>
   </nav>
  <!--Start of main section-->
   <main class="main">
     <h1>Below are funs to enjoy when you book with us</h1>
     <div class="flexParent">
        <img src="../assets/images/excursionSSwing.jpg" alt="quad dusty safari ride">
         <img src="../assets/images/excursionGPics.jpg" alt="raft ride group pic">
          <img src="../assets/images/excursionQuad.jpg" alt="quad safari ride on a safari trip">
           <img src="../assets/images/excursionRaft.jpg" alt="raft exploration ride on a safari trip">
     </div>
     <div class="flexParent">
           <img src="../assets/images/excursionRft.jpg" alt="raft ride on a safari trip">
          <img src="../assets/images/excursionSwing.jpg" alt="swing on a flowing river">
         <img src="../assets/images/excursionJRide.jpg" alt="landrover ride on a safari trip">
        <img src="../assets/images/excursionGroupPic.jpg" alt="swing across the river on a safari trip">
      </div>
    <div class="flexParent">
           <img src="../assets/images/excursionCliff.jpg" alt="raft ride on a safari trip">
          <img src="../assets/images/excursionBRide.jpg" alt="swing on a flowing river">
         <img src="../assets/images/excursionDustyQ.jpg" alt="landrover ride on a safari trip">
        <img src="../assets/images/excursionWDland.jpg" alt="swing across the river on a safari trip">
      </div> 
     <br>
    <div class="headList">
     <h2>The Names of Excursion Choices with Their Descriptions and Prices</h2></div>
    <div class="excursionDetails">
    <h3>Amalfi Coast Coach Tour -- Sorrento</h3>
     <p>A Day Coach trip to Amalfi Coast from Sorento. Take in all the beauty of the Amalfi Coast on a day trip from Sorrento. Explore the villages of Positano,        Amalfi, and Ravello during the tour.</p></div>
    <div class="excursionDetails">
    <h3>Capri Island Boat Trip -- Sorrento</h3>
     <p>Full-day tour of Capri island from Sorrento. Admire views along the coast as you cruise to the island.  Visit the island towns of beautiful Capri</p></div>
    <div class="excursionDetails">
     <h3>Ziplines thrilling experience rush--Aurira</h3>
      <p>Get ready for an unforgettable adventure in Side!For those seeking anadrenaline rush, this all-in-one tour combines the thrill of rafting on the Köprülü          Canyon River, a high-energy ATV safari through scenic forests, and a breathtaking zipline ride over the canyon. This activity, you will grab a specially          designed, metal wire and get to cross from the one side of the area to the other. The high speed, and the sense of flying will, surely, boost your energy               levels.</p></div>
   <div class="excursionDetails">
      <h3>Jeep Safari Biking … Aurira</h3>
       <p>Unleash your adventurous side with the Side Jeep Safari! Ride through forest trails, splash through muddy paths, and enjoy the thrill of off-road driving.             Along the way, you can observe some nice views. Perfect for adrenaline seekers of all experience levels. The rough off-road trail is about to excite and              thrill you! During the Jeep Safari. With this, your excitement would grow stronger</p></div>
   <div class="excursionDetails"> 
      <h3>Rafting a Recreational Outdoor Activities. -- Aurira</h3>
       <p>A Day Trip Super Combo Tour With Rafting, Get away from the crowds of the seaside, and immerse yourself into a fascinating exploration of the countryside!          </p></div>
   <div class="excursionDetails">
     <h3>Side Paragliding Experience--Aurira</h3>
      <p>Paragliding at Selgie with Coach trip from Aurira.</p></div>
   <div class="excursionDetails">
     <h3>Side Eagle Canyon Tour.---Selge</h3>
      <p>Explore Green Canyon on a relaxing boat cruise from Side, surrounded by towering cliffs and lush nature. Enjoy unlimited drinks and a delicious lunch while            basking in the tranquil beauty of one of Turkey’s most stunning natural retreats.</p></div>
  <div class="excursionDetails">
   <h3>Side Turkish Bath --Aurira</h3>
    <p>Turkish Bath experience in Aurira</p></div>
  <div class="excursionDetails">
    <h3>Scube Diving And Under Water Museum -- Sergel</h3> 
     <p>Embark on a mesmerizing diving adventure in Side, where crystal-clear Mediterranean waters await you. Dive to discover stunning underwater landscapes, exotic           marine life, and the mysteries hidden beneath the sea's surface. Professional scuba dive instructors will let you know about important safety and technical            information.</p></div>
  <div class="excursionDetails">
    <h3>Blau-Laguna fun center Boat trip.-- Pamukkale</h3>
      <p>Blau-Laguna lake Boat Trip from Aurira. "Get away from the crowds of the city, and spend a day full of fun and entertainment with our Blau Laguna Boat Trip.            This full day boat trip is ideal for people of all ages, and promises to fill you with cool memories. Swim in crystal clear waters, unwind on the decks and           soak up the sun, observe spectacular views, and spend quality time with your loved ones.</p></div>
  <div class="excursionDetails">
    <h3>Salda Lake And Pamukkale Day Trip -- Pamukkale</h3>
      <p>Immerse yourself in the beauty of nature with a day trip to the dazzling white terraces of Pamukkale and the serene turquoise waters of Salda Lake, a must-see            for lovers of unique landscapes</p></div>
  <div class="excursionDetails">
    <h3>Cadtach Coach tour and forest Jeep ride.-- Aurira</h3>
      <p>A day Coach tour to Cadtach from Aurari and forest Jeep ride."Get away from the crowds of the seaside, and immerse yourself into a fascinating 
        exploration of the countryside!  This Tour is just the perfect option for 
        those who seek to enjoy some adrenaline boosts while on holidays, as well as for 
        those who love alternative, outdoor activities.</p></div>
       <br>
  <div class="excursionList">
      <h3>Here is the Excursion list, location, and their prices.</h3>
         <ol class="excursionList">
            <li>Amalfi Coast coach tour, -- Location: Sorrento. ** Price: 70.00p/p.</li>
            <li>Boat trip to Capri island, -- Location: Sorrento. ** Price: 100.00p/p.</li>
            <li>Selgie Rafting Boat trip, -- Location: Capri Island. ** Price: 50.00p/p.</li>
            <li>Selgie Paragliding Coach trip, -- Location: Selgie. ** Price: 40.00p/p.</li>
            <li>Eagle Canyon Coach Tour, -- Location: Eagle Canyon. ** Price: 30.00p/p.</li>
            <li>Aurira Turkish Bath, -- Location: Aurari. ** Price: 70.00p/p.</li>
            <li>Scuba Diving Experience in Aurira, -- Location: Aurari. ** Price: 60.00p/p.</li>
            <li>Pamukkale AND Cotton Castle Coach trip, -- Location: Pamukkale. ** Price: 40.00p/p.</li>
            <li>Salda Lake Boat trip, -- Location: Salda Lake. ** Price: 50.00p/p.</li>
            <li>Blau-Laguna fun center Boat trip, -- Location: Blau-Laguna, ** Price: 40.00p/p.</li>
            <li>Pammukkale Mountain Coach trip for biking, -- Location: Pamukkale. ** Price: 40.00p/p.</li>
            <li>Cadtach Coach tour and forest Jeep ride, -- Location: Cadtach.  ** Price: 100.00p/p.</li>
        </ol>
   </div>
  </main>
 <!--Start of footer section-->
  <footer class="footer">Copyright &copy; 2020 Excursion Co.</footer>
 </div>
</body>
</html>