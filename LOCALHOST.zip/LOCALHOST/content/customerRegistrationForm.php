<?php
$username=$password=$confirm_password=$usernameErr=$passwordErr=$confirm_passwordErr=$customer_forename=$customer_surname=$customer_email=$date_of_birth="";
if(isset($_POST['submit'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];
  $confirm_password = $_POST['password'];

  $uppercase = preg_match('@[A-Z]@',$password);
  $lowercase = preg_match('@[a-z]@',$password);
  $number = preg_match('@[0-9]@', $password);
  $specialChars = preg_match('@[^\w]@', $password);

  if(empty($username)){
     $usernameErr= "username is mandatory!";
  }elseif(strlen($username)<=5){
    $usernameErr= "username should be at least 6 character";
  }elseif(strlen($username)>50){
    $usernameErr= "username should not be more than 50 character";
  }elseif(!$uppercase ||!$lowercase ||!$number ||!$specialChars || strlen($password) < 12) {
  $passwordErr ='Password should be at least 12 characters in length and should include at least
          one upper case letter, one number, and one special character.';
  }
}else{
    $passwordErr ='Password should be at least 12 characters with, 1 uppercase, 1 lowercase, 1special character and a number.';   
    $usernameErr= 'Username should be at least 6 character and not more than 50 character.';        
}

?>

<!doctype html> 
<html lang="en"> 
<head> 
 <meta charset="UTF-8">
 <title>Booking Process</title>
 <link rel="stylesheet" href="../assets/stylesheets/customerRegistrationStyle.css">
</head>
<body>
<!--Setting the Form Body for the required variables-->
 <div class="gridContainer">
 <!--Start of header section-->
 <header class="header">
    <img src="../assets/images/incoastlineIstanbul.jpg" alt="coastlineIstanbul">
    <h1>Register here!</h1>
    <p>If Already Registered!, Click login button to access site!</p>
 </header>
 <!--Start of nav section-->
 <nav class="nav">
    <ul>
         <li><a href='index.html'>Home</a></li>
         <li><a href='loginForm.php'>Login</a></li>
         <li><a href='logout.php'>Logout</a></li>
    </ul>
 </nav>
 <!--Start of main section-->
 <main class="main">
  <form action="customerRegistrationProcess.php" method="Post">
   <div class="intro">
    <h1>Customer Registration Form</h1>
   </div>
     <div class="line">
     <label for="username">Username:</label>
      <input type="text" id="username" name="username" > <?php echo $usernameErr        ?> <?php $username=  htmlspecialchars($username)?>
      </div>
     <div class="line">
     <label for="password">Password:</label> 
      <input type="password" id="password" name="password" > <?php echo        $passwordErr ?> <?php $password=  htmlspecialchars($password)?>
      </div>
      <div class="line">
         <label for="confirm_password">Confirm_Password:</label>  
          <input type="password" id="confirm_password" name="confirm_password" > <?php $confirm_password=  htmlspecialchars($confirm_password)?></div>
     <div class="line">
          <label for="customer_forename">Customer_Firstname:</label>
             <input type="text" id="customer_forename" name="customer_forename"><?php $customer_forename=  htmlspecialchars($customer_forename)?></div>
     <div class="line">
           <label for="customer_surname">Customer_Surname:</label>
              <input type="text" id="customer_surname" name="customer_surname"><?php $customer_surname=  htmlspecialchars($customer_surname)?></div>
     <div class="line">
        <label for="customer_email">Customer_Email:</label>
          <input type="email" id="customer_email" name="customer_email"><?php $customer_email=  htmlspecialchars($customer_email)?></div>
     <div class="line">
         <label for="date_of_birth">Date Of Birth:</label>
           <input type="date" id="date_of_birth" name="date_of_birth"><?php $date_of_birth=  htmlspecialchars($date_of_birth)?></div>
         <input type="submit" name="submit" value="Sign in">
   </form>
  </main>
 <!--Start of footer section-->
  <footer class="footer">Copyright &copy; 2020 Excursion Co.</footer>
 </div>
</body>
</html>

