<?php
ini_set("session.save_path", "C:/xampp/sessionData");  //adapt this to your //own folder structure for xampp if using xampp
//ini_set("session.save_path", "0;644;/var/www/html/sessionData"); 
session_start(); 

if (!isset($_SESSION['logged-in']) || $_SESSION['logged-in'] !== true) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html> 
<html lang="en"> 
 <head> 
  <meta charset="UTF-8">
  <title>Excursion</title>
  <link rel="stylesheet" href="../assets/stylesheets/excursionStyle.css">
 </head>
 <body>
  <div class="gridContainer">
    <!--Start of header section-->
    <header class="header">
      <img src="../assets/images/incoastlineIstanbul.jpg" alt="coastlineIstanbul">
      <h1>Excursion Selection</h1>
    </header>
    <!--Start of main navigation section-->
    <nav class="nav">
      <!--unordered list area in nav section-->
      <ul class="list"> 
        <li><a href="logout.php">Logout!</a></li>
        <li><a href="excursionDetailsPage.php">Excursion Details!</a></li>
        <li><a href="bookingForm.php">Booking!</a></li> 
        <li><a href="index.html">Home!</a></li> 
      </ul>
    </nav>
    <main class="main">
      <h2>Your Day Trip Excursion Selection Form!</h2>
      <p>Select Your Choice of Day Trip Excursion From Available Trip Options</p>
      <form id="excursion" action="excursionProcess.php" method="post">

        <div class="line">
          <!--Creating dynamically dropdown list of the excursions details-->
          <label for="excursion_select">Excursion Name:</label>
          <select name="excursionID" id="excursion_select" required>
            <option value="">-- Select an Excursion --</option>
            <?php
            // establishing database connection
            include('dbconn.php'); 
            
            // Query to get all excursion details from the excursions table
            $stmt = $conn->prepare("SELECT excursionID, excursion_name, description,                 price_per_person, location 
                    FROM excursions 
                    ORDER BY excursion_name ASC");
            $stmt->execute();
            $queryresult = $stmt->get_result();

            if ($queryresult && $queryresult->num_rows > 0) {
              while ($currentrow = $queryresult->fetch_assoc()) {
          // To Prevent XSS attack sanitizing the displaying data
                $ID = htmlspecialchars($currentrow['excursionID']);
                $name = htmlspecialchars($currentrow['excursion_name']);
                
                echo "<option value='$ID'>$name</option>";
              }
            }
            mysqli_free_result($queryresult);
            mysqli_close($conn);
            ?>
          </select>
        </div>

        <input type="submit" value="Select Excursion">
      </form>
    </main>
    <!--Start of footer section-->
    <footer class="footer">Copyright &copy; 2020 Excursion Co.</footer>
  </div>
</body>
</html>