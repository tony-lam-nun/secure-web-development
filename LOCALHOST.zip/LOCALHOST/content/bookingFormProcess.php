<?php
ini_set("session.save_path", "C:/xampp/sessionData");  //adapt this to your //own folder structure for xampp if using xampp
//ini_set("session.save_path", "0;644;/var/www/html/sessionData"); 
session_start(); 

if (!isset($_SESSION['logged-in']) || $_SESSION['logged-in'] !== true) {
    header("Location: login.php");
    exit();
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book A Tour</title>
</head>
<body>
<?php
/* Get each parameter value from the request stream and using ternary if operators 
check each parameter to see if it was set. If it is, store it in a variable. 
Otherwise store a value of null in the variable */

$excursion_date = array_key_exists('excursion_date', $_REQUEST) ? $_REQUEST['excursion_date'] : null;
$num_guests = array_key_exists('num_guests', $_REQUEST) ? $_REQUEST['num_guests'] : null;
$total_booking_cost = array_key_exists('total_booking_cost', $_REQUEST) ? $_REQUEST['total_booking_cost'] : null;
$booking_notes = array_key_exists('booking_notes', $_REQUEST) ? $_REQUEST['booking_notes'] : null;

$excursion_date = trim($excursion_date);
$num_guests = trim($num_guests);
$total_booking_cost = trim($total_booking_cost);
$booking_notes = trim($booking_notes);

$errors = false;

// Check for required variables and Validate entries
// Date Validation, ensure present or future dates
$today = date("Y-m-d");
$excursion_date = htmlspecialchars($excursion_date, ENT_QUOTES, 'UTF-8');
if (empty($excursion_date)) {
    echo "<p>You have not entered a valid excursion date</p>\n";
    $errors = true;
}
// the booking date input field would not allow past date
else if ($excursion_date < $today) {
         echo "<p>You cannot select a past date</p>\n";
         $errors = true;
}
 
// Validate num_guests as integer
$num_guests = htmlspecialchars($num_guests, ENT_QUOTES, 'UTF-8');
if (empty($num_guests)) {
    echo "<p>You have not entered the number of guests</p>\n";
    $errors = true;
} else if (!filter_var($num_guests, FILTER_VALIDATE_INT) || $num_guests < 1) {
    echo "<p>Number of guests must be a positive integer</p>\n";
    $errors = true;
}
// Validate total_booking_cost
$total_booking_cost= htmlspecialchars($total_booking_cost, ENT_QUOTES, 'UTF-8');
if (empty($total_booking_cost)) {
    echo "<p>You have not entered total booking cost</p>\n";
    $errors = true;
}
// preventing invalid entries other than figures
else if(!filter_var($total_booking_cost, FILTER_VALIDATE_FLOAT)) {
    echo "<p>The total booking cost should be a number</p>\n";
    $errors = true;
}
// Sanitize and validate booking notes 
$booking_notes = htmlspecialchars($booking_notes, ENT_QUOTES, 'UTF-8'); 
if (empty($booking_notes)) {
    echo "<p>You have not entered booking notes</p>\n";
    $errors = true;
}
// setting maximum characters for notes
else if(strlen($booking_notes) > 1000) { 
     echo "<p>booking notes exceeds maximum allowed length of characters</p>\n";
    $errors = true;
}
// preventing invalid entries
else if (!preg_match('/^[\w\s.,!?-]*$/u', $booking_notes)) {
    echo "<p>You have  entered Invalid characters booking notes</p>\n";
    $errors = true;
} 

if ($errors) {
    echo "<p>Please try <h2><a href='bookingForm.php'>again</a></h2></p>\n";
}
else {
	require_once 'functions.php';
	$conn = getConnection();

     //insert the form input into the database with secure statement
	$insertSQL = "INSERT INTO booking (excursion_date, num_guests, total_booking_cost, booking_notes) 
				  VALUES(?, ?, ?, ?)";

	//prepare statement to prevent SQL injection    
	  if ($stmt = mysqli_prepare($conn,$insertSQL)){
		// Bind variables to the prepared statement as parameters
		mysqli_stmt_bind_param($stmt, "sids", $excursion_date, $num_guests, $total_booking_cost, $booking_notes);
		$queryresult = mysqli_stmt_execute($stmt);//returns boolean
		
		if (!$queryresult) {
			echo "<p>Error: " . htmlspecialchars(mysqli_stmt_error($stmt), ENT_QUOTES, 'UTF-8'). "</p>";
		}
		mysqli_close($conn);
	}
	else {
		echo "Could not prepare statement";
	}
	
        // Show success message with output
        echo "<div>";
        echo "<h1>Submitted Booking Form Received! ✓</h1>";
        echo "<p><strong>Your booking has been successfully         recorded as!.</strong></p>";
        echo "</div>";        

        echo "<h2>Booking Details:</h2>";
        echo "<h3><strong>Excursion Date:</strong> " . htmlspecialchars($excursion_date, ENT_QUOTES, 'UTF-8') . "</h3>";
        echo "<h3><strong>Number Of Guests:</strong> " . htmlspecialchars($num_guests, ENT_QUOTES, 'UTF-8') . "</h3>";
        echo "<h3><strong>Total Booking Cost:</strong> " . htmlspecialchars(number_format($total_booking_cost, 2), ENT_QUOTES, 'UTF-8') . "</h3>";
        echo "<h3><strong>Booking Notes:</strong> " . htmlspecialchars($booking_notes, ENT_QUOTES, 'UTF-8') . "</h3>";
        
	
} 

        // Navigation links
        echo "<hr>";
        echo "<h2>Navigation:</h2>";
        echo "<h2><a href='excursionForm.php'>Excursion</a></h2>\n";
        echo "<h2><a href='bookingForm.php'>Make Another Booking</a></h2>\n";
        echo "<h2><a href='index.html'>Home</a></h2>\n"; 
        echo "<h2><a href='logout.php'>Logout</a></h2>\n"; 
            
?>

</body>
</html>