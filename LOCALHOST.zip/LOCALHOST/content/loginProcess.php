<?php 
ini_set("session.save_path", "C:/xampp/sessionData");  //adapt this to your own //folder structure for xampp if using xampp
//ini_set("session.save_path", "0;644;/var/www/html/sessionData"); 
session_start(); 

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book A Tour</title>
</head>
<body>

<?php

//the password and username form validation
//define variable and set to empty values
$usernameErr = $passwordErr = "";
$username = $password = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["username"])) {
       $usernameErr = "Username is required";
    }else{
       $username = test_input($_POST["username"]);
    }
    
    if (empty($_POST["password"])) {
       $passwordErr = "Password is required";
    }else{
       $password = test_input($_POST["password"]);
    }
 }

 function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
 }
//Retrieve the username and the password from the form
$username = array_key_exists('username', $_REQUEST)? $_REQUEST['username']: null; 
$password = array_key_exists('password', $_REQUEST)? $_REQUEST['password']: null;

//To take care of space bar whitespace
$username = trim($username);
$password = trim($password);

// Make a database connection
require_once 'functions.php';
$conn = getConnection();

/* Query the customers database table to get the password_hash for the username entered by 
the user, using a placeholder for the username */
$querySQL = "SELECT password_hash FROM customers WHERE username = ?";

// Prepare the sql statement 
$stmt = mysqli_prepare($conn, $querySQL);

//Bind variables to the prepared statement as parameters
mysqli_stmt_bind_param($stmt, "s", $username);

// Execute the query 
mysqli_stmt_execute($stmt);

/* Check if a record was returned by the query. If yes, then there was a username matching what was entered in the logon form and we can test 
to see if the password entered in the logon form
was correct. Otherwise, indicate an error. */
 
$queryresult = mysqli_stmt_get_result($stmt);

//turn the resultset into an associative array
$userRow = mysqli_fetch_assoc($queryresult);

if ($userRow) {
   $password_hash = $userRow['password_hash'];  
       if (password_verify ($password, $userRow["password_hash"]) == TRUE) {
           //if the password and username were both valid
	   $_SESSION['logged-in'] = true;
           echo "Welcome!, the username and password were correct";
           header('Location: restrictedpage.php'); // to redirect immediately
       }
       else {
               // the username or password were incorrect.    
          echo "<h3>Incorrect UserName or Password!</h3>\n";
          echo "<h3><a href ='loginForm.php'>Incorrect UserName and Password!, Try again!</a></h3>\n";
         
       }

header('Location: restrictedpage.php'); // to redirect immediately
//header('Refresh: 1; url=restrictedpage.php');  to redirect after a 1 second delay
}
?>
</body>
</html>