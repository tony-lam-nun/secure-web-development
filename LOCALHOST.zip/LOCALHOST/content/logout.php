<?php
ini_set("session.save_path", "C:/xampp/sessionData");  //adapt this to your //own folder structure for xampp if using xampp
//ini_set("session.save_path", "0;644;/var/www/html/sessionData"); 
session_start();

?>


<!DOCTYPE html>
<html lang="en">
 <head>
     <meta charset="utf-8" />
     <title>LOGOUT/title>
     <link rel='stylesheet' href='../assets/css/logoutCss.css'>
 </head>
<body>
//end and destroy session that has been started for security reason
<?php

session_start();

session_unset();

session_destroy();

header('Location: loginForm.php');

?>

</body>
</html>