<?php
ini_set("session.save_path", "C:/xampp/sessionData");  //adapt this to your own folder structure for xampp if using xampp
//ini_set("session.save_path", "0;644;/var/www/html/sessionData"); 
session_start(); 
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book A Tour</title>
</head>
<body>
<?php
/* Get each parameter value from the request stream and using ternary if operators 
check each parameter to see if it was set. If it is, store it in a variable. 
Otherwise store a value of null in the variable */
$username = array_key_exists('username', $_REQUEST) ? $_REQUEST['username'] : null;
$password = array_key_exists('password', $_REQUEST) ? $_REQUEST['password'] : null;
$customer_forename = array_key_exists('customer_forename', $_REQUEST) ? $_REQUEST['customer_forename'] : null;
$customer_surname = array_key_exists('customer_surname', $_REQUEST) ? $_REQUEST['customer_surname'] : null;
$customer_email = array_key_exists('customer_email', $_REQUEST) ? $_REQUEST['customer_email'] : null;
$date_of_birth = array_key_exists('date_of_birth', $_REQUEST) ? $_REQUEST['date_of_birth'] : null;


$username = trim($username);
$password = trim($password);
$customer_forename = trim($customer_forename);
$customer_surname = trim($customer_surname);
$customer_email = trim($customer_email);
$date_of_birth = trim($date_of_birth);




$errors = false;

// Validate Username
$username=  htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); 
if (empty($username)) {
     echo "User Name 
       is required";
     echo "<p><h3><a href='customerRegistrationForm.php'>Back</a></h3></p>";
    $errors = true;
      exit();
}

if(strlen($username)<=5){
    echo "username should be 
        at least 6 character";
    echo "<p><h3><a href='customerRegistrationForm.php'>Back</a></h3></p>";
    $errors = true;
    exit();
}

if(strlen($username)>50){
    echo "username should not be 
        more than 50 character";
    echo "<p><h3><a href='customerRegistrationForm.php'>Back</a></h3></p>";
    $errors = true;
    exit();
}
//Validate Password
$password=  htmlspecialchars($password, ENT_QUOTES, 'UTF-8');
if (empty($password)) {
     echo "Password 
       is required";
     echo "<p><h3><a href='customerRegistrationForm.php'>Back</a></h3></p>";
    $errors = true;
    exit();
}

elseif (strlen($password) < 12) {
    echo "Password must contain at least
       12 characters";
    echo "<p><h3><a href='customerRegistrationForm.php'>Back</a></h3></p>";
   $errors = true;
   exit();
}

elseif (!preg_match("#[0-9]+#", $password)) {
    echo "Password 
       must include at least one number";
    echo "<p><h3><a href='customerRegistrationForm.php'>Back</a></h3></p>";
     $errors = true;
    exit();

}elseif (!preg_match("#[A-Z]+#", $password)) {
     echo "Password 
       must include at least one uppercase letter";
     echo "<p><h3><a href='customerRegistrationForm.php'>Back</a></h3></p>";
     $errors = true;
    exit();

}elseif (!preg_match("#[a-z]+#", $password)) {
     echo "Password  must include at least
        one lowercase letter";
     echo "<p><h3><a href='customerRegistrationForm.php'>Back</a></h3></p>";
     $errors = true;
     exit();

}elseif (!preg_match("#[^\w]+#", $password)) {
     echo "Password must include at 
        least one specialcharacter";
     echo "<p><h3><a href='customerRegistrationForm.php'>Back</a></h3></p>";
     $errors = true;
     exit();
// Check for Confirm_Password equal to Main Password
}elseif ($_POST['password'] !== $_POST['confirm_password']) {
     echo "Your passwords did not match.";
     echo "<p><h3><a href='customerRegistrationForm.php'>Back</a></h3></p>";
     $errors = true;
     exit();
}
// Validate customer_forename
$customer_forename=  htmlspecialchars($customer_forename, ENT_QUOTES, 'UTF-8');
if (empty($customer_forename)) {
    echo "Customer 
       forename is required";
    echo "<p><h3><a href='customerRegistrationForm.php'>Back</a></h3></p>";
    $errors = true;
     exit();
}

// Validate customer_surname
$customer_surname=  htmlspecialchars($customer_surname, ENT_QUOTES, 'UTF-8');
if (empty($customer_surname)) {
    echo "Customer 
       surname is required";
    echo "<p><h3><a href='customerRegistrationForm.php'>Back</a></h3></p>";
    $errors = true;
    exit();
}
// Validate Email Address 
$customer_email=  htmlspecialchars($customer_email, ENT_QUOTES, 'UTF-8');
if (empty($customer_email)) {
    echo "Customer 
       Email address is required";
    echo "<p><h3><a href='customerRegistrationForm.php'>Back</a></h3></p>";
    $errors = true;
    exit();

}
// check if e-mail address syntax is valid
elseif(!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$customer_email)) {
     echo "You Entered An Invalid 
          Email Format";
     echo "<p><h3><a href='customerRegistrationForm.php'>Back</a></h3></p>";
     $errors = true;
     exit();
}
// Validate Date of Birth
$date_of_birth=  htmlspecialchars($date_of_birth, ENT_QUOTES, 'UTF-8');
if (empty($date_of_birth)) {
    echo "Customer date_of_birth
       is required";
    echo "<p><h3><a href='customerRegistrationForm.php'>Back</a></h3></p>";
    $errors = true;
     exit();
} 
else {
      // data connection
	require_once 'functions.php';
	$conn = getConnection();
   /* To check for duplicate username with data input prevention from sql injection vulnerabilities using prepare statement */
   // Get user input from the form to compare 
       $username = $_POST['username'];

       //Check if username already exists
       $sql = "SELECT username FROM customers WHERE username = ?";     
       // Prepare statement
       $stmt = $conn->prepare($sql);
       // bind variable to the prepared statement
       $stmt->bind_param("s", $username);
       // Execute statement
       $stmt->execute();
       $stmt->store_result();
       // Check if the input name already exist or not
       if ($stmt->num_rows > 0) {
          echo "<p>Username already exist. Please choose a again.</p>\n";
          echo "<p>You will be redirected back to re-register.</p>\n";
           header('Refresh: 2; url=customerRegistrationForm.php');
           exit();
        } else {
            echo "Username is available to use";
        }
   
   // The function automatically generates cryptographical safe salt
       //Hash a new password for storing in the database
        $password = password_hash($password, PASSWORD_DEFAULT);

	$insertSQL = "INSERT INTO customers (username, password_hash, customer_forename, customer_surname, customer_email, date_of_birth) 
				  VALUES(?, ?, ?, ?, ?, ?)";
				  
	  if ($stmt = mysqli_prepare($conn,$insertSQL)){
	   // Bind variables to the prepared statement as parameters
		mysqli_stmt_bind_param($stmt, "ssssss", $username, $password,  $customer_forename, $customer_surname, $customer_email, $date_of_birth);
                // Execute the query
		$queryresult = mysqli_stmt_execute($stmt);//returns boolean
             
		if (!$queryresult) {
			echo "<p>Error: " . htmlspecialchars(mysqli_stmt_error($stmt), ENT_QUOTES, 'UTF-8'). "</p>";
		}
		mysqli_close($conn);
	}
	else {
		echo "Could not prepare statement";
	}
	
	echo "<h1>Customer Registration!</h1>\n";
       // Prevent XSS using htmlspecialchars()
        echo "<h3><strong>Username:</strong> " . htmlspecialchars($username, ENT_QUOTES, 'UTF-8') . "</h3>\n";
	echo "<h3><strong>Password Hash:</strong> " . htmlspecialchars($password, ENT_QUOTES, 'UTF-8') . "</h3>\n";
	echo "<h3><strong>Customer Forename:</strong> " . htmlspecialchars($customer_forename, ENT_QUOTES, 'UTF-8') . "</h3>\n";
	 echo "<h3><strong>Customer Surname:</strong> " . htmlspecialchars($customer_surname, ENT_QUOTES, 'UTF-8') . "</h3>\n";
	echo "<h3><strong>Customer Email:</strong> " . htmlspecialchars($customer_email, ENT_QUOTES, 'UTF-8') . "</h3>\n";	
        echo "<h3><strong>Date Of Birth:</strong> " . htmlspecialchars($date_of_birth, ENT_QUOTES, 'UTF-8') . "</h3>\n";
        
 
}       
        echo "<br>";
        echo "Hello. $username. Welcome! You have successfully Registered\n";
        //header("Location:loginForm.php"); //Redirection without any delay
          header("Refresh: 2; url=loginForm.php"); //Redirection with a delay of 2sec.

 
     
?>

</body>
</html>