<?php 
ini_set("session.save_path", "C:/xampp/sessionData");  //adapt this to your //own folder structure for xampp if using xampp
//ini_set("session.save_path", "0;644;/var/www/html/sessionData"); 
session_start();  



?>

<!DOCTYPE html>
<html lang="en">
 <head>
     <meta charset="utf-8" >
     <title>LOGIN</title>
     <link rel='stylesheet' href='../assets/stylesheets/loginFormCss.css'>
 </head>
 <body>
  <div class="gridContainer">
 <!--Start of header section-->
 <header class="header">
    <img src="../assets/images/incoastlineIstanbul.jpg" alt="coastlineIstanbul">
    <h1>As a Registered Customer, Login to access restricted area!</h1>
    <p>Not Yet Registered, Click customer-registration link below!</p>
 </header>
 <!--Start of nav section-->
 <nav class="nav">
    <ul>
         <li><a href='index.html'>Home</a></li>
         <li><a href='customerRegistrationForm.php'>Customer-Registration</a></li>
         <li><a href='logout.php'>Logout</a></li>
    </ul>
 </nav> 
 <!--Start of main section-->
 <main class="main">  
  <form method="post" action="loginProcess.php">
      <div class="intro">
         <h1>Login</h1>
      </div>
     <div class="intro">
        <label for="username">Username:</label> 
         <input type="text" id="username" name="username"> <?php $username=""?> <?php $username=  htmlspecialchars($username)?>
     </div>
     <div class="intro">
         <label for="password">Password:</label>
           <input type="password" id="password" name="password"><?php $password=""?> <?php $password=  htmlspecialchars($password)?>
     </div>
           <input type="submit" value="Logon">
  </form>
 </main>
 <!--Start of footer section-->
  <footer class="footer">Copyright &copy; 2020 Excursion Co.</footer>
 </div>
 </body>
</html>


    