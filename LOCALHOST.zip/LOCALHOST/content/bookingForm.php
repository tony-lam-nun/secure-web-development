<?php
ini_set("session.save_path", "C:/xampp/sessionData");  //adapt this to your //own folder structure for xampp if using xampp
//ini_set("session.save_path", "0;644;/var/www/html/sessionData"); 
session_start(); 

if (!isset($_SESSION['logged-in']) || $_SESSION['logged-in'] !== true) {
    header("Location: login.php");
    exit();
}
?>


<!doctype html> 
<html lang="en"> 
<head> 
 <meta charset="UTF-8">
 <title>Booking Process</title>
 <link rel="stylesheet" href='../assets/stylesheets/bookingCss.css'>
</head>
<body>
  <div class="gridContainer">
   <!--Start of header section-->
      <header class="header">
         <img src="../assets/images/incoastlineIstanbul.jpg" alt="coastlineIstanbul">
          <h1>Make Booking For Day Trip Excursion Here!</h1>
      </header>
  <!--Start of nav section-->
  <nav class="nav">
    <ul>
         <li><a href='logout.php'>Logout</a></li>
         <li><a href='excursionForm.php'>Excursion</a></li>
         <li><a href='excursionDetailsPage.php'>Excursion Details</a></li>
         <li><a href='index.html'>Home</a></li>
    </ul>
  </nav>
  <!--Start of main section-->
  <main class="main">
    <form action="bookingFormProcess.php" method="Post">
       <div class="intro">
          <h1>Your Booking Form</h1>
        </div>
   <!--excursionID and customerID not in this form, they are configured in the database to take same ID no. as bookingID being the primary key-->
     <div class="line">
     <label for="excursion_date">Excursion Date:</label>
      <input type="date" id="excursion_date" name="excursion_date"></div>
         <div class="line">
            <label for="num_guests">Number Of Guests:</label>
              <input type="text" id="num_guests" name="num_guests"></div>
                <div class="line">
             <label for="total_booking_cost">Total Booking Cost:</label>
              <input type="text" id="total_booking_cost" name="total_booking_cost"></div>
             <div class="line">
               <label for="booking_notes">Booking Notes:</label>
          <textarea id="booking_notes" name="booking_notes"></textarea></div>
        <input type="submit" value="Submit Form!">
    </form>
   </main>
 <!--Start of footer section-->
   <footer class="footer">Copyright &copy; 2020 Excursion Co.</footer>
  </div>
 </body>
</html>

