<?php
ini_set("session.save_path", "C:/xampp/sessionData");  //adapt this to your //own folder structure for xampp if using xampp
//ini_set("session.save_path", "0;644;/var/www/html/sessionData"); 
session_start();
 
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  	<title>Login process script</title>
</head>
<body>
<?php
// using the session variable 'logged-in' as the indicator that the user is logged in.
if (array_key_exists('logged-in',$_SESSION)) {
    //that is, if ($_SESSION['logged-in']==true)
     if ($_SESSION['logged-in']) {
		echo "<a href='logout.php'>Logout</a>";

                if (isset($_SESSION['logged-in']) && $_SESSION['logged-in']==true) {
			echo "<p><h1>Welcome! This page could now display information / provide functionality that requires to restrict access to.</h1></p>\n";
                        header('Refresh: 2; url=restricted.php'); //with 2 secs delay
		}
	}
	else {
		echo "<p>You need to be logged in to access this page.</p>";
	}
}
else {
	echo "<p>You need to be logged in to access this page.</p>";
        echo "<a href='loginForm.php'>Login again</a>\n";
}
?>

</body>
</html>