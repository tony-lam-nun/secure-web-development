<?php
ini_set("session.save_path", "C:/xampp/sessionData");  //adapt this to your //own folder structure for xampp if using xampp
//ini_set("session.save_path", "0;644;/var/www/html/sessionData"); 
session_start(); 

if (!isset($_SESSION['logged-in']) || $_SESSION['logged-in'] !== true) {
    header("Location: login.php");
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
 <head>
       <meta charset="utf-8">
       <title>DayTrip</title>
       <link href="../assets/stylesheets/restrictedCss.css" rel="stylesheet" type="text/css">
 </head>
  <body>
 <!--Setting the gridContainerForm Body for the required variables-->
 <div class="gridContainer">
 <!--Start of header section-->
 <header class="header">
    <img src="../assets/images/firstdirecthotelmin.jpg" alt="hotelresortIstanbul">
    <h1>Restricted Area, Step in to explore!</h1>
    <p>Welcome, this page links to all the restricted pages of the site!</p> 
 </header>
 <!--Start of nav section-->
 <nav class="nav">
    <ul>
         <li><a href='index.html'>Home</a></li>
         <li><a href='bookingForm.php'>Booking</a></li>
         <li><a href='excursionForm.php'>Excursion</a></li>
         <li><a href='excursionDetailsPage.php'>Excursion Details</a></li>
         <li><a href='logout.php'>Logout</a></li>
    </ul>
 </nav>
 <!--Start of main section-->
 <main class="main">
   <h1>Excursion DayTrip</h1>
   <h2>Welcome!, Among Others You can make your Bookings Here!</h2>
     <h3>Day Trip Excursion/ Option Levels/Family, Group, And Individual. Below is for General Information Only.</h3>
   <p>For detail information on Exursion trips, Go to Excursion details page and Excursion page, you would get full Information for all the available excursions day trip choices, and the Selection of Excursion choices respectively.</p>
 <!--16 pictures of yoyful tourists participating in the day trip excursion -->
     <div class="flexParent">
      <img src="../assets/images/beachsittingarea.jpg" alt="sitting on the beach">
       <div class="flow">
        <h4>Basic:</h4>
         <h4>£40 p/p</h4>
       </div>
       <img src="../assets/images/blueskysea.jpeg" alt="sea side view on the horizon">
         <div class="flow">
          <h4>Deluxe:</h4>
          <h4>£70 p/p</h4>
         </div>
         <img src="../assets/images/heavywindseaside.jpg" alt="beach wind blowing">
         <div class="flow">  
          <h4>Diamond:</h4>
          <h4>£100 p/p</h4>
         </div>
         <img src="../assets/images/woodenhideout.jpeg" alt="wooden cool hideout">
         <div class="flow">
          <h4>Presidential:</h4>
          <h4>£120 p/p</h4>
         </div>
     </div>
     <br>
     <div class="flexParent">
         <img src="../assets/images/asset2people.jpg" alt="individual picture">
         <div class="flow">    
           <h4>Basic/group:</h4>
            <h4>£80 p/p</h4>
         </div>
         <img src="../assets/images/assetpeople.jpg" alt="individual picture">
         <div class="flow">
           <h4>Deluxe/group:</h4>
           <h4>£90 p/p</h4>
         </div>
         <img src="../assets/images/corporate.jpeg" alt="individual picture">
         <div class="flow">
           <h4>Diamond/grp:</h4>
            <h4>£110 p/p</h4>
         </div>
          <img src="../assets/images/relazingscene.jpeg" alt="individual picture">
         <div class="flow">     
            <h4>Presidential/grp:</h4>
            <h4>£120 p/p</h4>
         </div>
     </div>
     <br>
     <div class="flexParent">
         <img src="../assets/images/smiley.jpg" alt="individual picture">
         <div class="flow">    
          <h4>Basic/family:</h4>
           <h4>£100/family</h4>
         </div>
          <img src="../assets/images/simplicity.jpg" alt="individual picture">
          <div class="flow">
           <h4>Deluxe/family:</h4>
           <h4>£120/family</h4>
          </div>
          <img src="../assets/images/innermost1.jpg" alt="individual picture">
          <div class="flow">
           <h4>Diamond/family:</h4>
           <h4>£145/family</h4>
          </div>
          <img src="../assets/images/emancipate.jpg" alt="individual picture">
          <div class="flow">  
           <h4>Presidential/family:</h4>
           <h4>£160/family</h4>
          </div>
     </div> 
  </main>
  <!--Start of footer section-->
  <footer class="footer">Copyright &copy; 2020 Excursion Co.</footer>
  </div>
</body>
</html>