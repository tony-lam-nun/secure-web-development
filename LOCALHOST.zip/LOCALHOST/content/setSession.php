<?php 
ini_set("session.save_path", "C:/xampp/sessionData");  //adapt this to your //own folder structure for xampp if using xampp
//ini_set("session.save_path", "0;644;/var/www/html/sessionData"); 
session_start();
 

?> 

<!DOCTYPE html>
<html lang="en">
 <head>
     <meta charset="utf-8" />
     <title>setSession</title>
 </head>
<body> 
 <?php
 $_SESSION['firstname'] = 'Tony';
   echo "\n<p>session has been set</p>\n";
   echo $_SESSION['firstname'];

 ?>
</body>
</html>



